   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                   &copy; Library Management System |<a href="https://google.com/" target="_blank"  > Designed by : Batch C-12</a> 
                </div>

            </div>
        </div>
    </section>