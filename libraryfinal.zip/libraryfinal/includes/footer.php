   <section class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                       Library Management System |<a href="https://google.com/" target="_blank"  > Developed by:Batch C12</a> 
                </div>

            </div>
        </div>
    </section>